/* real.c */

int main(void)
{
    double pi, ln2;
    double max_flt, min_flt;

    pi = 3.14159265358979323846;
    ln2 = 0.69314718055994530942;
    max_flt = 3.402823e+38;
    min_flt = 1.175494E-38;
}
